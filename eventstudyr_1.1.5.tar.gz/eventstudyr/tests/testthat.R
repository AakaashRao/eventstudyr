library(testthat)
library(eventstudyr)

test_check("eventstudyr")
