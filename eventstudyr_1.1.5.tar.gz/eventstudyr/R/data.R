#' Sample dataset obtained from the replication archive for Freyaldenhoven et al. (2021)
#'
#' @source Dataset in .dta format can be found in the .zip archive in \url{https://data.nber.org/data-appendix/w29170/}
"example_data"

